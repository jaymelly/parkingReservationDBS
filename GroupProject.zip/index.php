<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="index.css">
	<title>CityParking</title>
</head>

<body>
	<header class="header" style="font-size: 40px; margin-left: 10px">Wonderville City Parking</header>
	<section class="sidebar">
    		<div class="grid-item"><a href="index.php">Home</a></div>
		<div class="grid-item"><a href="UserInterface.php">User Page</a></div>
		<div class="grid-item"><a href="login.php">Admin Portal</a></div>
	</section>

        <main class="main">
		<h2>Enter as User</h2>
		<a href="UserInterface.php"><button>Go To User Page</button> 
	</main>

</body>
</html>
